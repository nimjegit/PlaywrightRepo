const {test,expect} = require('@playwright/test');

const AxeBuilder = require('@axe-core/playwright').default;

//we use {} to pick only test property from all properties 
// of {@playwright/test}: destructuring

/*Here the browser is a playwright fixture.
Its ready to use. We can use it to create a new page and perform actions on it.*/

test('first test case',{tag:'@smoke'},async({browser}) =>{
const context = await browser.newContext();
const page = await context.newPage();
await page.goto('https://www.google.com/');
console.log("Navigated to google successfully");
});

test('second test case',{tag:'@smoke'}, async({page}) => {
   await page.goto('https://www.google.com/');
   const pagetitle = await page.title();
   await expect(pagetitle).toBe("Google");
    console.log("Expected and Actual is same: " +pagetitle);
});


test.only('Asseccibility testing',async({page})=>{
    await page.goto("https://example.com");
    const results = await new AxeBuilder({page}).analyze();
    expect(results.violations).toHaveLength(3);
});

